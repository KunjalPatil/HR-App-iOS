//
//  ViewController.swift
//  HRAppIOS
//
//  Created by macadmin on 2016-11-18.
//  Copyright © 2016 macadmin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtPayrollResult: UITextView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtSalary: UITextField!
    @IBOutlet weak var txtBonus: UITextField!
    @IBOutlet weak var txtRate: UITextField!
    @IBOutlet weak var txtHours: UITextField!
    @IBOutlet weak var txtMake: UITextField!
    @IBOutlet weak var txtPlate: UITextField!
    
    @IBOutlet weak var lblMessage: UILabel!
    
    var arrEmployee : [Employee] = [Employee]()
    var currentEmployee : Employee? = nil
    
    // research on convenience constructor
    // research on required constructor
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBOutlet weak var txtSchoolName: UITextField!
    
    @IBAction func btnAdd(_ sender: UIButton) {
        if (!(txtSalary.text?.isEmpty)!) && (!(txtBonus.text?.isEmpty)!) {
        
            // FullTime
            var ft1 : FullTime
            var v1 : Vehicle?
            
            if (!(txtPlate.text?.isEmpty)!) && (!(txtMake.text?.isEmpty)!) {
                // employee does have a vehil=cle to be registered
                v1 = Vehicle(pPlate: txtPlate.text!,pMake: txtMake.text!)
            } else {
                v1 = nil
            }
            
            ft1 = FullTime(name: txtName.text! , age: Int(txtAge.text!)!, salary: Int(txtSalary.text!)!, bonus: Int(txtBonus.text!)!, pPV: v1)
            
            arrEmployee.append(ft1)
            currentEmployee = ft1
            
            lblMessage.text = "FT Emp Added"
            
        } else if (!(txtRate.text?.isEmpty)!) && (!(txtHours.text?.isEmpty)!) {
            // Partime
           
            var pt1 : PartTime
            var v1 : Vehicle?
            
            if (!(txtPlate.text?.isEmpty)!) && (!(txtMake.text?.isEmpty)!) {
                // employee does have a vehil=cle to be registered
                v1 = Vehicle(pPlate: txtPlate.text!,pMake: txtMake.text!)
            } else {
                v1 = nil
            }
            
            pt1 = PartTime(name: txtName.text! , age: Int(txtAge.text!)!, hoursWorked: Int(txtHours.text!)!, rate: Int(txtRate.text!)!, pPV: v1)
            
            arrEmployee.append(pt1)
            currentEmployee = pt1
            
            lblMessage.text = "PT Emp Added"
        } else if !((txtSchoolName.text?.isEmpty)!){
            // intern
            
            
            var it1 : Intern
            var v1 : Vehicle?
            
            if (!(txtPlate.text?.isEmpty)!) && (!(txtMake.text?.isEmpty)!) {
                // employee does have a vehil=cle to be registered
                v1 = Vehicle(pPlate: txtPlate.text!,pMake: txtMake.text!)
            } else {
                v1 = nil
            }
            
            it1 = Intern(name: txtName.text! , age: Int(txtAge.text!)!, collegeName: txtSchoolName.text!, pPV: v1)
            
            arrEmployee.append(it1)
            currentEmployee = it1
            
            lblMessage.text = "Intern Emp Added"
        }
        
        
    }
    
    @IBAction func btnCalcPayroll(_ sender: UIButton) {
        var totalPR = 0
        var earn = 0
        var result : String = ""
        for i in 0..<arrEmployee.count {
            result += "\n"
            result = result + "Name: " + arrEmployee[i].getName()
            result += "\n"
            result += "Age: \(arrEmployee[i].getAge())"
            result += "\n"
            
            print ("***************************")
            arrEmployee[i].displayData()
            print ("***************************")
            
            earn = arrEmployee[i].calcEarnings()
            print ("Earnings : \(earn)")
            result += "Earnings : \(earn)"
            totalPR = totalPR + earn
        }
        
        print ("Total Payroll: \(totalPR)")
        result += "\n"
        result += "Total Payroll: \(totalPR)"
        
        txtPayrollResult.text = result
        
    }
    
    @IBAction func btnSearchByName(_ sender: UIButton) {
        
        let nameToSearch = txtName.text
        var found = false
        
        for i in 0..<arrEmployee.count {
            if arrEmployee[i].getName() == nameToSearch {
                currentEmployee = arrEmployee[i]
                // update UI
                display (currentEmployee)
                found = true
                break
            }
            
        }
        
        if !found {
            lblMessage.text = "Not Found"
        } else {
            lblMessage.text = "Employee Found"
        }
        
      
    }
    
    fileprivate func display(_ e: Employee?) {
        
        ClearField(false)
        
        if let empRef = e as? FullTime {
            txtName.text = empRef.getName()
            txtAge.text = String(empRef.getAge())
            txtSalary.text = String(empRef.salary)
            txtBonus.text = String(empRef.bonus)
        }
        
        if let empRef = e as? PartTime {
            txtName.text = empRef.getName()
            txtAge.text = String(empRef.getAge())
            txtRate.text = String(empRef.rate)
            txtHours.text = String(empRef.hoursWorked)
        }
        
        if let empRef = e as? Intern {
            txtName.text = empRef.getName()
            txtAge.text = String(empRef.getAge())
            txtSchoolName.text = String(empRef.collegeName)
        }
        
        if (e?.vehicle_owned != nil) {
            txtPlate.text = e?.vehicle_owned?.plateNumber
            txtMake.text = e?.vehicle_owned?.make
        }
        
   
    }
    
    fileprivate func ClearField(_ shouldClearName: Bool ) {
        
        txtName.text = shouldClearName == true ? "" : txtName.text
        txtAge.text = ""
        txtSalary.text = ""
        txtBonus.text = ""
        txtSchoolName.text = ""
        txtRate.text = ""
        txtHours.text = ""
        txtPlate.text = ""
        txtMake.text = ""
        txtPayrollResult.text = ""

    }
    
    
    @IBAction func txtChange(_ sender: UIButton) {
        
        if let empRef = currentEmployee as? FullTime {
            empRef.setName(txtName.text!)
            empRef.setAge(Int(txtAge.text!)!)
            empRef.salary = Int(txtSalary.text!)!
            empRef.bonus = Int(txtBonus.text!)!
        }
        
        if let empRef = currentEmployee as? PartTime {
            empRef.setName(txtName.text!)
            empRef.setAge(Int(txtAge.text!)!)
            empRef.rate = Int(txtRate.text!)!
            empRef.hoursWorked = Int(txtHours.text!)!
        }
        
        if let empRef = currentEmployee as? Intern {
            empRef.setName(txtName.text!)
            empRef.setAge(Int(txtAge.text!)!)
            empRef.collegeName = txtSchoolName.text!
        }
        
        if (currentEmployee?.vehicle_owned != nil) {
            currentEmployee!.vehicle_owned!.plateNumber = txtPlate.text!
            currentEmployee?.vehicle_owned?.make = txtMake.text!
        }

    }
    
    @IBAction func btnClear(_ sender: UIButton) {
        ClearField(true)
    }
    
}

