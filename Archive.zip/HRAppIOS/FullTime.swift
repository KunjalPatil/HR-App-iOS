open class FullTime : Employee {
    open var salary : Int = 0
    open var bonus : Int = 0
    
    override init() {
        super.init()
        salary = 0
        bonus = 0
    }
    
    init (name:String, age:Int, salary:Int, bonus:Int, pPV: Vehicle?)
    {
        super.init(pName: name, pAge: age, pV: pPV!)
        self.salary = salary
        self.bonus = bonus
    }
    
    init (name:String, age:Int, salary:Int, bonus:Int, pPPlate: String, pPMake: String)
    {
        super.init(pName: name, pAge: age, pPlate: pPPlate, pMake: pPMake)
        self.salary = salary
        self.bonus = bonus
    }
    
    
    open override func calcEarnings() -> Int {
        return (salary + bonus)
    }
    
    open override func displayData() {
        super.displayData()
        print ("Salary: \(self.salary)")
        print ("Bonus: \(self.bonus)")
    }
    
    
    
}

