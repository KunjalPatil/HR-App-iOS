open class Employee : IDisplayable {
    fileprivate var name : String
    fileprivate var age : Int
    open var vehicle_owned : Vehicle?
    
    open func setName (_ pName : String)
    {
        self.name = pName
    }
    
    open func getName() -> String {
        return self.name
    }
    
    open func setAge (_ pAge : Int)
    {
        if pAge > 0 {
            self.age = pAge
        } else {
            print("Invalid Age")
        }
    }
    
    open func getAge() -> Int {
        return self.age
    }
    
    
    init() {
        name = ""
        age = 0
        vehicle_owned = nil
    }
    
    init (pName :  String, pAge : Int, pV : Vehicle?) {
        self.name = pName
        self.age = pAge
        self.vehicle_owned = pV
        
    }
    
    init (pName :  String, pAge : Int, pPlate : String, pMake : String) {
        
        self.name = pName
        self.age = pAge
        self.vehicle_owned = Vehicle(pPlate: pPlate, pMake: pMake)
        
    }
    
    open func CalcBirthYear() -> Int {
        return 2016 - self.age
    }
    
    open func calcEarnings() -> Int {
        return 1000
    }
    
    open func displayData() {
        print ("Name: \(self.name)")
        print ("Age: \(self.age)")
        if vehicle_owned != nil {
            vehicle_owned?.displayData()
        } else {
            print ("No Vehicle registered")
        }
    }
  
    
}

