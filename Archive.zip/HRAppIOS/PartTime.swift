open class PartTime : Employee {
    open var hoursWorked : Int
    open var rate : Int
    
    override init() {
        hoursWorked = 0
        rate = 0
        super.init()
    }
    
    init (name:String, age:Int, hoursWorked:Int, rate:Int, pPV: Vehicle?)
    {
        self.hoursWorked = hoursWorked
        self.rate = rate
        super.init(pName: name, pAge: age, pV: pPV)
    }
    
    init (name:String, age:Int, hoursWorked:Int, rate:Int, pPPlate : String, pPMake : String)
    {
        self.hoursWorked = hoursWorked
        self.rate = rate
        super.init(pName: name, pAge: age, pPlate: pPPlate, pMake: pPMake)
    }
    
    
    open override func calcEarnings() -> Int {
        return (hoursWorked * rate)
    }
    
    open override func displayData() {
        super.displayData()
        print ("HoursWorked: \(self.hoursWorked)")
        print ("Rate: \(self.rate)")
    }
    
    
    
    
}
