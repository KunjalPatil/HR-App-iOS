open class Vehicle : IDisplayable {
    
    open var plateNumber : String
    open var make : String
    
    init() {
        plateNumber = ""
        make = ""
        
    }
    
    init (pPlate : String, pMake : String) {
        plateNumber = pPlate
        make = pMake
    }
    
    open func displayData() {
        print ("Vehicle Make: \(self.make)")
        print ("Vehicle Plate: \(self.plateNumber)")
        
    }
    
    
}
