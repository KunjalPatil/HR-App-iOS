open class Intern : Employee {
    open var collegeName : String
    
    override init() {
        collegeName = ""
        super.init()
    }
    
    init (name:String, age:Int, collegeName:String, pPV: Vehicle?)
    {
        self.collegeName = collegeName
        super.init(pName: name, pAge: age, pV: pPV)
    }
    
    init (name:String, age:Int, collegeName:String, pPPlate: String, pPMake: String)
    {
        self.collegeName = collegeName
        super.init(pName: name, pAge: age, pPlate: pPPlate, pMake: pPMake)
    }
    
    open override func displayData() {
        super.displayData()
        print ("School: \(self.collegeName)")
    }
    
}

