public protocol IDisplayable {
    func displayData()
}

